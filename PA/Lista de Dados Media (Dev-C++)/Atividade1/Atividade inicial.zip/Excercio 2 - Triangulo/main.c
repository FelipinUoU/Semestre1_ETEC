#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	
float base, alt, area;	

printf ("Digite o valor da altura da piramide: ");
scanf ("%f", &alt);

printf ("Digite o valor da base da piramide: ");
scanf ("%f", &base);

	area= (base*alt)/2;

printf ("toma o resultado: %.1f", area); 







return 0;
}

