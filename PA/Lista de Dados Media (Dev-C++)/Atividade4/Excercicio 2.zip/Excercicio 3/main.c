#include <stdio.h>
#include <stdlib.h>

/*Isso � uma obs*/

int main(int argc, char *argv[]) {
	
float num1, num2, soma;	
	
printf ("coloca um numero ai vai: ");	
scanf ("%f", &num1);	
	
printf ("coloca um outro numero agora: ");	
scanf ("%f", &num2);		

soma = num1+num2;
	
if (soma>25)
	printf("sua soma � maior de que 25");
	
	
	
	
	
	
	
	
	
	return 0;
}
